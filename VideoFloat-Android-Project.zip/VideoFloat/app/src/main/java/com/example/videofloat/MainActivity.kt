package com.example.videofloat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val inputs = mutableListOf<EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(24, 24, 30))
        }
        root.addView(TextView(this).apply {
            text = "Video Float"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "وارد کردن لینک صفحه یا ویدیو (حداکثر ۴ مورد)"
            textSize = 16f
            setTextColor(Color.LTGRAY)
        })
        repeat(4) { i ->
            inputs += EditText(this).apply {
                hint = "لینک ${i + 1} (اختیاری)"
                setSingleLine(true)
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
            }
            root.addView(inputs.last())
        }
        root.addView(Button(this).apply {
            text = "فعال‌کردن مجوز پنجره شناور"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "مجوز از قبل فعال است", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "باز کردن پنجره شناور"
            setOnClickListener {
                val urls = inputs.map { it.text.toString().trim() }
                    .filter { it.startsWith("https://") || it.startsWith("http://") }
                if (urls.isEmpty()) {
                    Toast.makeText(this@MainActivity, "حداقل یک لینک https:// وارد کن", Toast.LENGTH_LONG).show()
                } else if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "اول مجوز پنجره شناور را فعال کن", Toast.LENGTH_LONG).show()
                } else {
                    val intent = Intent(this@MainActivity, FloatingVideoService::class.java)
                    intent.putStringArrayListExtra("urls", ArrayList(urls.take(4)))
                    startService(intent)
                    finish()
                }
            }
        })
        setContentView(root)
    }
}
