package com.example.videofloat

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingVideoService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        removeOverlay()
        val urls = intent?.getStringArrayListExtra("urls") ?: arrayListOf()
        if (urls.isEmpty()) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(35, 35, 40))
        }
        bar.addView(TextView(this).apply {
            text = "Video Float  •  بستن"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(12, 8, 12, 8)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(Button(this).apply {
            text = "×"
            setOnClickListener { stopSelf() }
        })
        root.addView(bar)
        urls.forEach { url ->
            val web = WebView(this)
            web.setBackgroundColor(Color.BLACK)
            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.settings.mediaPlaybackRequiresUserGesture = true
            web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            web.webChromeClient = WebChromeClient()
            web.loadUrl(url)
            root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        overlay = root
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            (resources.displayMetrics.heightPixels * 0.62f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 80 }
        try { wm.addView(root, params) } catch (e: Exception) {
            Toast.makeText(this, "پنجره شناور باز نشد: مجوز را بررسی کن", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    override fun onDestroy() { removeOverlay(); super.onDestroy() }
}
