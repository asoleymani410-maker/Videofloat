# Video Float (prototype)

Android prototype for displaying up to four user-provided web URLs in an overlay window.

## Build
Run `gradle assembleDebug` with Android SDK / build-tools installed, or use the GitHub Actions workflow in `.github/workflows/build.yml`.

## Limitations
- This is a prototype, not a production-ready player.
- Web pages such as KICK may block embedded playback or require login/gestures.
- Android may limit simultaneous video playback and overlay behavior by device/OS.
- Review permissions and test before relying on it.
